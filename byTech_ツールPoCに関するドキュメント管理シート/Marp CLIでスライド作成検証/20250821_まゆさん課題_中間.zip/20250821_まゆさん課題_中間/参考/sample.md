---
marp: true
size: 16:9
paginate: true
---

<style>
@import url('./theme.css');
</style>

<!-- 
  スライド1: 表紙スライド (title.jpg)
-->
<!-- _class: title -->
![bg](./講座スライド素材/title.jpg)

<div class="title-container">
  <div class="catch-copy">ビジネスを変える！</div>
  <div class="main-title">デジタルマーケティング<br>基礎セミナー</div>
  <div class="instructor">代表講師</div>
  <div class="instructor-name">舟洞 真如</div>
</div>

---
<!-- 
  スライド2: STEP4の目的とゴール (goal.jpg)
-->
<!-- _class: goal -->
![bg](./講座スライド素材/goal.jpg)

<div class="blue-header">STEP4の目的とゴール</div>

<div class="content-section">
  <div class="content-purpose">このセミナーでは、デジタルマーケティングの基本的な概念を学び、実践的なスキルを身につけることを目指します。このセミナーでは、デジタルマーケティングの基本的な概念を学び、実践的なスキルを身につけることを目指します。</div>

  <div class="content-goal">このセミナーでは、デジタルマーケティングの基本的な概念を学び、実践的なスキルを身につけることを目指します。このセミナーでは、デジタルマーケティングの基本的な概念を学び、実践的なスキルを身につけることを目指します。</div>
</div>

<!-- <div class="copyright">©THE SALES DESIGN</div> -->

---
<!-- 
  スライド3: なぜデザインが成約率を左右するのか？ (kihon.jpg)
-->
<!-- _class: kihon -->
![bg](./講座スライド素材/kihon.jpg)

<div class="blue-header">なぜデザインが成約率を左右するのか？</div>

<div class="section-title">＜デザインが顧客の信頼と行動に与える影響＞</div>

<div class="content-section">
  <div class="content-text">
  このセミナーでは、デジタルマーケティングの基本的な概念を学び、実践的なスキルを身につけることを目指します。このセミナーでは、デジタルマーケティングの基本的な概念を学び、実践的なスキルを身につけることを目指します。
  </div>
  
  <div class="content-text">
  このセミナーでは、デジタルマーケティングの基本的な概念を学び、実践的なスキルを身につけることを目指します。このセミナーでは、デジタルマーケティングの基本的な概念を学び、実践的なスキルを身につけることを目指します。
  </div>
</div>

<!-- <div class="copyright">©THE SALES DESIGN</div> -->

---
<!-- 
  スライド4: 目次 (mokuji.jpg)
-->
<!-- _class: mokuji -->
![bg](./講座スライド素材/mokuji.jpg)

<div class="content-list">
  <div>目的とゴールの確認</div>
  <div>なぜデザインが成約率を左右するのか？</div>
  <div>デザインの4大原則（理論編）</div>
  <div>LPデザインレギュレーション解説</div>
  <div>厳選デザインツールと参考サイト活用術</div>
  <div>LPの画像素材を準備する</div>
  <div>課題</div>
</div>

<!-- <div class="copyright">©THE SALES DESIGN</div> -->

---
<!-- 
  スライド5: STEP4 セクション (tobira.jpg)
-->
<!-- _class: tobira -->
![bg](./講座スライド素材/tobira.jpg)

<div class="step-number">STEP4</div>
<div class="step-title">LPデザイン設計</div>

---
<!-- 
  スライド6: 課題 (kadai.jpg)
-->
<!-- _class: kadai -->
![bg](./講座スライド素材/kadai.jpg)

<div class="blue-header">課題</div>

<div class="section-title">＜STEP4の課題1＞</div>

<div class="content-section">
  <div class="content-text">このセミナーでは、デジタルマーケティングの基本的な概念を学び、実践的なスキルを身につけることを目指します。このセミナーでは、デジタルマーケティングの基本的な概念を学び、実践的なスキルを身につけることを目指します。</div>
  
  <div class="content-text">このセミナーでは、デジタルマーケティングの基本的な概念を学び、実践的なスキルを身につけることを目指します。このセミナーでは、デジタルマーケティングの基本的な概念を学び、実践的なスキルを身につけることを目指します。</div>
</div>

<!-- <div class="copyright">©THE SALES DESIGN</div> -->
