---
marp: true
size: 16:9
paginate: true
---

<style>
@import url('./theme.css');
</style>

<!-- 
  スライド1: 表紙スライド (title.jpg)
-->
<!-- _class: title -->
![bg](./講座スライド素材/title.jpg)

<div class="title-container">
  <div class="catch-copy">ビジネスを変える！</div>
  <div class="main-title">デジタルマーケティング<br>基礎セミナー</div>
  <div class="instructor">代表講師</div>
  <div class="instructor-name">舟洞 真如</div>
</div>

---
<!-- 
  スライド2: ゴール提示用 (goal.jpg)
-->
<!-- _class: goal -->
![bg](./講座スライド素材/goal.jpg)

<div class="blue-header">STEP4の目的とゴール</div>

<div class="content-section">
  <div class="content-purpose">このセミナーでは、デジタルマーケティングの基本的な概念を学び、実践的なスキルを身につけることを目指します。このセミナーでは、デジタルマーケティングの基本的な概念を学び、実践的なスキルを身につけることを目指します。</div>

  <div class="content-goal">このセミナーでは、デジタルマーケティングの基本的な概念を学び、実践的なスキルを身につけることを目指します。このセミナーでは、デジタルマーケティングの基本的な概念を学び、実践的なスキルを身につけることを目指します。</div>
</div>

---
<!-- 
  スライド3: 基本の本文用 (kihon.jpg) - 基本スタイルテスト
-->
<!-- _class: kihon -->
![bg](./講座スライド素材/kihon.jpg)

# 見出し1のテスト（H1）

## 見出し2のテスト（H2）

### 見出し3のテスト（H3）

これは**強調テキスト**を含む本文のテストです。基本的なパラグラフのスタイルが適用されているかを確認できます。

- リストアイテム1
- リストアイテム2  
- リストアイテム3

1. 番号付きリスト1
2. 番号付きリスト2
3. 番号付きリスト3

> これは引用テキストのテストです。ブロッククォートのスタイルが正しく適用されているかを確認します。

---
<!-- 
  スライド4: 目次用 (mokuji.jpg)
-->
<!-- _class: mokuji -->
![bg](./講座スライド素材/mokuji.jpg)

<div class="content-list">
  <div>目的とゴールの確認</div>
  <div>なぜデザインが成約率を左右するのか？</div>
  <div>デザインの4大原則（理論編）</div>
  <div>LPデザインレギュレーション解説</div>
  <div>厳選デザインツールと参考サイト活用術</div>
  <div>LPの画像素材を準備する</div>
  <div>課題</div>
</div>

---
<!-- 
  スライド5: 章の扉用 (tobira.jpg)
-->
<!-- _class: tobira -->
![bg](./講座スライド素材/tobira.jpg)

<div class="step-number">STEP4</div>
<div class="step-title">LPデザイン設計</div>

---
<!-- 
  スライド6: 課題提示用 (kadai.jpg)
-->
<!-- _class: kadai -->
![bg](./講座スライド素材/kadai.jpg)

<div class="blue-header">課題</div>

<div class="section-title">＜STEP4の課題1＞</div>

<div class="content-section">
  <div class="content-text">このセミナーでは、デジタルマーケティングの基本的な概念を学び、実践的なスキルを身につけることを目指します。このセミナーでは、デジタルマーケティングの基本的な概念を学び、実践的なスキルを身につけることを目指します。</div>
  
  <div class="content-text">このセミナーでは、デジタルマーケティングの基本的な概念を学び、実践的なスキルを身につけることを目指します。このセミナーでは、デジタルマーケティングの基本的な概念を学び、実践的なスキルを身につけることを目指します。</div>
</div>
